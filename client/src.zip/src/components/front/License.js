import React, { Component } from 'react'

export default class License extends Component {
    render() {
        return (
            <div>
                <h1>i m licence</h1>
            </div>
        )
    }
}
