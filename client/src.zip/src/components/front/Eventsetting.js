import React, { Component } from 'react'

export default class Eventsetting extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}