import React, { Component } from 'react'

export default class Eventnominfo extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}