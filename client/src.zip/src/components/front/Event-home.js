import React, { Component } from 'react'

export default class Eventhome extends Component {
    render() {
        return (
            <div>
                <div className="contain_home">
                    <div className="left_home">
                        <img src="./img/kuria-new.png" alt="" className="event_img" />
                        <i className="fa fa-home home_icon"></i>
                        <i className="fa fa-gear home_icon"></i>
                        <i className="fa fa-th home_icon"></i>
                        <i className="fa fa-trash home_icon"></i>
                    </div>
                    
                    <div className="right_home">

                    </div>
                </div>
            </div>
        )
    }
}
