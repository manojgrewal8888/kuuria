import React, { Component } from 'react'

export default class Emailhead extends Component {
    render() {
        return (
            <div>
                <div className="head_mail">
                    <img src="./img/kuria-new.png" alt="" className="img_mail" />
                    <p className="para_mail">We Create You Celibrate ....</p>
                </div>
            </div>
        )
    }
}
