import React, { Component } from 'react'

export default class Eventdelete extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
