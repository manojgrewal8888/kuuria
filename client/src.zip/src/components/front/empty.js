import React, { Component } from 'react'

export default class empty extends Component {
    render() {
        return (
            <div>
                <h1>opppssss u landed on empty link</h1>
            </div>
        )
    }
}
