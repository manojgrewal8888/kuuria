import React, { Component } from 'react'

export default class Votesubmit extends Component {
    render() {
        return (
            <div>
                <div className="wrapvote_browse">
                    <img src="./img/conf.png" alt="" className="conf_res" />
                    <img src="./img/highfive.png" alt="" className="resize_submi" />
                    <p className="vote_submitp">Vote Submitted</p>
                </div>
            </div>
        )
    }
}