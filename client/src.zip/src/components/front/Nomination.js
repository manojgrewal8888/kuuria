import React, { Component } from 'react'

export default class Nomination extends Component {
    render() {
        return (
            <div>
                <h1>this in Nomination</h1>
            </div>
        )
    }
}
